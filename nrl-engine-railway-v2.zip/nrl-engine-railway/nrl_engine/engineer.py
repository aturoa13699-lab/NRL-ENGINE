"""
NRL Feature Engineering v3.0

Implements the 5-Layer Vector Hierarchy from "Vectorized Advantage" framework:
1. Fundamentals: ELO, Pythagorean Expectation
2. Personnel: VORP proxies, squad variance
3. Context: HGA, Fatigue, Travel
4. Stylistic: Attack/Defense matchups, efficiency
5. Volatility: Referee, Momentum σ, Weather

Plus market reverse-engineering vectors.
All features are PIT-safe (Point-in-Time validated).
"""

from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
import numpy as np
import pandas as pd
import logging

from nrl_engine.config import config

logger = logging.getLogger(__name__)


# =============================================================================
# VENUE DATA (Travel/HGA calculations)
# =============================================================================

VENUE_COORDS = {
    "suncorp_stadium": (-27.465, 153.010),
    "accor_stadium": (-33.847, 151.063),
    "aami_park": (-37.825, 144.983),
    "commbank_stadium": (-33.807, 151.007),
    "4_pines_park": (-33.795, 151.285),
    "bluebet_stadium": (-33.751, 150.690),
    "pointsbet_stadium": (-34.046, 151.116),
    "mcdonald_jones_stadium": (-32.923, 151.721),
    "qld_country_bank": (-19.259, 146.817),
    "cbus_super_stadium": (-28.007, 153.429),
    "go_media_stadium": (-36.888, 174.784),
    "giokunos_stadium": (-35.242, 149.097),
}

TEAM_HOME_VENUES = {
    "Brisbane Broncos": "suncorp_stadium",
    "Melbourne Storm": "aami_park",
    "Penrith Panthers": "bluebet_stadium",
    "Sydney Roosters": "accor_stadium",
    "South Sydney Rabbitohs": "accor_stadium",
    "Cronulla Sharks": "pointsbet_stadium",
    "Parramatta Eels": "commbank_stadium",
    "Manly Sea Eagles": "4_pines_park",
    "Canterbury Bulldogs": "accor_stadium",
    "Newcastle Knights": "mcdonald_jones_stadium",
    "North Queensland Cowboys": "qld_country_bank",
    "Gold Coast Titans": "cbus_super_stadium",
    "New Zealand Warriors": "go_media_stadium",
    "Canberra Raiders": "giokunos_stadium",
    "St George Illawarra Dragons": "accor_stadium",
    "Wests Tigers": "accor_stadium",
    "Dolphins": "suncorp_stadium",
}

VENUE_HGA_MULT = {
    "qld_country_bank": 1.4,
    "go_media_stadium": 1.35,
    "aami_park": 1.2,
    "4_pines_park": 1.25,
    "default": 1.0,
}


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two points in km."""
    R = 6371
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    return R * 2 * np.arcsin(np.sqrt(a))


# =============================================================================
# FEATURE ENGINEER CLASS
# =============================================================================

class FeatureEngineer:
    """
    Comprehensive NRL Feature Engineering.
    
    Processes raw match data to create derived vectors for prediction.
    """
    
    def __init__(self, historical_data: Optional[pd.DataFrame] = None):
        """
        Initialize with historical data.
        
        Args:
            historical_data: DataFrame with past matches for computing rolling stats
        """
        self.historical = historical_data
        self.team_games: Dict[str, pd.DataFrame] = {}
        self.elo_ratings: Dict[str, float] = {}
        self.elo_history: List[Tuple] = []
        self.referee_stats: Dict[str, pd.DataFrame] = {}
        
        if historical_data is not None and not historical_data.empty:
            self._prepare_historical()
    
    def _prepare_historical(self) -> None:
        """Prepare historical data indices."""
        df = self.historical.copy()
        
        # Ensure datetime
        if not pd.api.types.is_datetime64_any_dtype(df['date']):
            df['date'] = pd.to_datetime(df['date'], errors='coerce')
        
        df = df.sort_values('date').reset_index(drop=True)
        self.historical = df
        
        # Build team index
        self._build_team_index()
        
        # Initialize ELO
        self._init_elo()
        
        # Build referee index
        if 'referee' in df.columns:
            self._build_referee_index()
        
        logger.info(f"✅ Prepared {len(df)} historical matches")
    
    def _build_team_index(self) -> None:
        """Build per-team game history."""
        df = self.historical
        teams = pd.unique(pd.concat([df['home_team'], df['away_team']]))
        
        for team in teams:
            mask = (df['home_team'] == team) | (df['away_team'] == team)
            team_df = df[mask].copy()
            
            team_df['is_home'] = team_df['home_team'] == team
            team_df['pf'] = np.where(team_df['is_home'], team_df['home_score'], team_df['away_score'])
            team_df['pa'] = np.where(team_df['is_home'], team_df['away_score'], team_df['home_score'])
            team_df['margin'] = team_df['pf'] - team_df['pa']
            team_df['win'] = (team_df['margin'] > 0).astype(int)
            
            self.team_games[team] = team_df.sort_values('date')
    
    def _init_elo(self) -> None:
        """Initialize and compute ELO through history."""
        k = config.elo_k
        hga = config.elo_home_advantage
        
        teams = list(self.team_games.keys())
        self.elo_ratings = {t: config.elo_initial for t in teams}
        
        current_season = None
        
        for _, row in self.historical.iterrows():
            home, away = row['home_team'], row['away_team']
            match_date = row['date']
            
            # Season regression
            match_season = match_date.year if hasattr(match_date, 'year') else None
            if match_season and current_season and match_season > current_season:
                reg = config.elo_season_regression
                for team in self.elo_ratings:
                    self.elo_ratings[team] = (
                        self.elo_ratings[team] * (1 - reg) +
                        config.elo_initial * reg
                    )
            current_season = match_season
            
            # Store pre-match
            self.elo_history.append((match_date, row.get('match_id', ''), home, self.elo_ratings.get(home, 1500)))
            self.elo_history.append((match_date, row.get('match_id', ''), away, self.elo_ratings.get(away, 1500)))
            
            # Calculate expected
            home_elo = self.elo_ratings.get(home, 1500) + hga
            away_elo = self.elo_ratings.get(away, 1500)
            exp_home = 1 / (1 + 10 ** ((away_elo - home_elo) / 400))
            
            # Margin multiplier
            margin = row['home_score'] - row['away_score']
            margin_mult = np.log(max(abs(margin), 1) + 1) * 0.5 + 0.5
            
            # Result
            if margin > 0:
                actual = 1
            elif margin < 0:
                actual = 0
            else:
                actual = 0.5
            
            # Update
            adj_k = k * margin_mult
            self.elo_ratings[home] = self.elo_ratings.get(home, 1500) + adj_k * (actual - exp_home)
            self.elo_ratings[away] = self.elo_ratings.get(away, 1500) + adj_k * ((1 - actual) - (1 - exp_home))
    
    def _build_referee_index(self) -> None:
        """Build referee statistics."""
        df = self.historical
        
        for ref in df['referee'].dropna().unique():
            ref_games = df[df['referee'] == ref].copy()
            ref_games['total_points'] = ref_games['home_score'] + ref_games['away_score']
            ref_games['margin'] = abs(ref_games['home_score'] - ref_games['away_score'])
            
            if 'home_penalties' in ref_games.columns:
                ref_games['total_penalties'] = ref_games['home_penalties'] + ref_games['away_penalties']
                ref_games['penalty_diff'] = ref_games['away_penalties'] - ref_games['home_penalties']
            
            self.referee_stats[ref] = ref_games.sort_values('date')
    
    def _get_elo_at_date(self, team: str, date) -> float:
        """Get team's ELO before a date (PIT-safe)."""
        history = [(d, elo) for d, mid, t, elo in self.elo_history if t == team and d < date]
        return history[-1][1] if history else config.elo_initial
    
    def _get_team_history(self, team: str, before) -> pd.DataFrame:
        """Get team's game history before a date."""
        if team not in self.team_games:
            return pd.DataFrame()
        
        df = self.team_games[team]
        return df[df['date'] < before].sort_values('date', ascending=False)
    
    # =========================================================================
    # LAYER 1: FUNDAMENTAL VECTORS
    # =========================================================================
    
    def _compute_elo(self, home: str, away: str, date) -> Dict[str, Any]:
        """ELO vectors."""
        home_elo = self._get_elo_at_date(home, date)
        away_elo = self._get_elo_at_date(away, date)
        
        elo_diff = home_elo - away_elo + config.elo_home_advantage
        elo_exp = 1 / (1 + 10 ** (-elo_diff / 400))
        
        return {
            'home_elo': home_elo,
            'away_elo': away_elo,
            'elo_diff': elo_diff,
            'elo_exp_home': elo_exp,
            'elo_exp_margin': elo_diff * 0.04,
        }
    
    def _compute_pythagorean(self, home_hist: pd.DataFrame, away_hist: pd.DataFrame, window: int = 10) -> Dict[str, Any]:
        """Pythagorean expectation."""
        exp = config.pythagorean_exponent
        
        def calc(hist):
            if len(hist) < 3:
                return None
            recent = hist.head(window)
            pf, pa = recent['pf'].sum(), recent['pa'].sum()
            if pf + pa <= 0:
                return None
            return (pf ** exp) / ((pf ** exp) + (pa ** exp))
        
        home_p, away_p = calc(home_hist), calc(away_hist)
        
        return {
            'home_pythag': home_p,
            'away_pythag': away_p,
            'pythag_diff': home_p - away_p if home_p and away_p else None,
        }
    
    # =========================================================================
    # LAYER 2: ROLLING FORM VECTORS
    # =========================================================================
    
    def _compute_rolling(self, hist: pd.DataFrame, window: int, prefix: str) -> Dict[str, Any]:
        """Rolling statistics."""
        features = {
            f'{prefix}_{window}_games': 0,
            f'{prefix}_{window}_pf': None,
            f'{prefix}_{window}_pa': None,
            f'{prefix}_{window}_margin': None,
            f'{prefix}_{window}_win_rate': None,
        }
        
        if hist.empty or len(hist) < config.min_games_for_rolling:
            return features
        
        recent = hist.head(window)
        features[f'{prefix}_{window}_games'] = len(recent)
        features[f'{prefix}_{window}_pf'] = float(recent['pf'].mean())
        features[f'{prefix}_{window}_pa'] = float(recent['pa'].mean())
        features[f'{prefix}_{window}_margin'] = float(recent['margin'].mean())
        features[f'{prefix}_{window}_win_rate'] = float(recent['win'].mean())
        
        return features
    
    # =========================================================================
    # LAYER 3: CONTEXT VECTORS
    # =========================================================================
    
    def _compute_hga(self, home: str, away: str, venue: Optional[str]) -> Dict[str, Any]:
        """Home ground advantage."""
        venue_key = venue.lower().replace(' ', '_') if venue else 'default'
        hga_mult = VENUE_HGA_MULT.get(venue_key, VENUE_HGA_MULT['default'])
        
        # Travel distance
        travel_km = None
        if venue_key in VENUE_COORDS and away in TEAM_HOME_VENUES:
            away_home = TEAM_HOME_VENUES[away]
            if away_home in VENUE_COORDS:
                v_coords = VENUE_COORDS[venue_key]
                a_coords = VENUE_COORDS[away_home]
                travel_km = haversine_km(v_coords[0], v_coords[1], a_coords[0], a_coords[1])
        
        travel_penalty = 0.0
        if travel_km:
            if travel_km > 1500:
                travel_penalty = -3.5
            elif travel_km > 800:
                travel_penalty = -2.0
            elif travel_km > 300:
                travel_penalty = -1.0
        
        return {
            'venue_hga_mult': hga_mult,
            'away_travel_km': travel_km,
            'travel_penalty': travel_penalty,
            'adjusted_hga': 3.5 * hga_mult + travel_penalty,
        }
    
    def _compute_fatigue(self, home_hist: pd.DataFrame, away_hist: pd.DataFrame, date) -> Dict[str, Any]:
        """Fatigue/rest vectors."""
        def days_since(hist):
            if hist.empty:
                return None
            return max(0, (date - hist['date'].iloc[0]).days)
        
        home_rest = days_since(home_hist)
        away_rest = days_since(away_hist)
        
        def penalty(days):
            if days is None:
                return 0.0
            if days <= 5:
                return -3.0
            if days <= 6:
                return -1.5
            if days >= 10:
                return 1.0
            return 0.0
        
        return {
            'home_rest_days': home_rest,
            'away_rest_days': away_rest,
            'rest_diff': home_rest - away_rest if home_rest and away_rest else None,
            'fatigue_advantage': penalty(home_rest) - penalty(away_rest),
        }
    
    # =========================================================================
    # LAYER 4: MATCHUP VECTORS
    # =========================================================================
    
    def _compute_h2h(self, home: str, away: str, date, window: int = 10) -> Dict[str, Any]:
        """Head-to-head history."""
        if self.historical is None:
            return {'h2h_games': 0, 'h2h_home_win_rate': None, 'h2h_margin': None}
        
        mask = (
            ((self.historical['home_team'] == home) & (self.historical['away_team'] == away)) |
            ((self.historical['home_team'] == away) & (self.historical['away_team'] == home))
        )
        h2h = self.historical[mask & (self.historical['date'] < date)]
        
        if h2h.empty:
            return {'h2h_games': 0, 'h2h_home_win_rate': None, 'h2h_margin': None}
        
        recent = h2h.sort_values('date', ascending=False).head(window)
        
        home_wins, total_margin = 0, 0
        for _, row in recent.iterrows():
            if row['home_team'] == home:
                home_wins += int(row['home_score'] > row['away_score'])
                total_margin += row['home_score'] - row['away_score']
            else:
                home_wins += int(row['away_score'] > row['home_score'])
                total_margin += row['away_score'] - row['home_score']
        
        return {
            'h2h_games': len(recent),
            'h2h_home_win_rate': home_wins / len(recent),
            'h2h_margin': total_margin / len(recent),
        }
    
    # =========================================================================
    # LAYER 5: VOLATILITY VECTORS
    # =========================================================================
    
    def _compute_volatility(self, home_hist: pd.DataFrame, away_hist: pd.DataFrame) -> Dict[str, Any]:
        """Volatility (σ) vectors."""
        def calc_vol(hist, default=12.0):
            if len(hist) < 5:
                return default
            return float(hist.head(10)['margin'].std())
        
        home_v, away_v = calc_vol(home_hist), calc_vol(away_hist)
        
        return {
            'home_volatility': home_v,
            'away_volatility': away_v,
            'match_volatility': (home_v + away_v) / 2,
        }
    
    def _compute_momentum(self, hist: pd.DataFrame, prefix: str) -> Dict[str, Any]:
        """Momentum vectors."""
        if len(hist) < 6:
            return {f'{prefix}_momentum': None, f'{prefix}_streak': 0}
        
        # Streak
        streak = 0
        for _, row in hist.iterrows():
            if row['win'] == 1:
                if streak >= 0:
                    streak += 1
                else:
                    break
            else:
                if streak <= 0:
                    streak -= 1
                else:
                    break
        
        # Momentum score
        recent = hist.head(5)
        wr = recent['win'].mean()
        margin_norm = np.clip((recent['margin'].mean() + 30) / 60, 0, 1)
        momentum = (wr * 0.6 + margin_norm * 0.4) * 100
        
        return {
            f'{prefix}_momentum': momentum,
            f'{prefix}_streak': streak,
        }
    
    def _compute_referee(self, referee: Optional[str], date) -> Dict[str, Any]:
        """Referee vectors."""
        base = {'ref_games': 0, 'ref_penalty_rate': None, 'ref_home_bias': None}
        
        if not referee or referee not in self.referee_stats:
            return base
        
        ref_hist = self.referee_stats[referee]
        ref_hist = ref_hist[ref_hist['date'] < date]
        
        if len(ref_hist) < config.ref_min_games:
            base['ref_games'] = len(ref_hist)
            return base
        
        n = len(ref_hist)
        base['ref_games'] = n
        
        if 'total_penalties' in ref_hist.columns:
            base['ref_penalty_rate'] = float(ref_hist['total_penalties'].mean())
        
        if 'penalty_diff' in ref_hist.columns:
            raw = ref_hist['penalty_diff'].mean()
            shrink = n / (n + config.ref_shrinkage_strength)
            base['ref_home_bias'] = float(raw * shrink)
        
        base['ref_avg_total'] = float(ref_hist['total_points'].mean())
        base['ref_blowout_rate'] = float((ref_hist['margin'] > 18).mean())
        
        return base
    
    # =========================================================================
    # MARKET VECTORS
    # =========================================================================
    
    def _compute_market(self, home_odds: Optional[float], away_odds: Optional[float]) -> Dict[str, Any]:
        """Market reverse-engineering vectors."""
        if not home_odds or not away_odds or home_odds <= 1 or away_odds <= 1:
            return {
                'market_home_fair': None,
                'market_overround': None,
                'market_implied_margin': None,
            }
        
        home_imp = 1 / home_odds
        away_imp = 1 / away_odds
        total = home_imp + away_imp
        
        home_fair = home_imp / total
        overround = total - 1
        
        implied_margin = np.log(home_fair / (1 - home_fair)) * 6 if home_fair > 0.5 else -np.log((1 - home_fair) / home_fair) * 6
        
        return {
            'market_home_fair': home_fair,
            'market_overround': overround,
            'market_implied_margin': implied_margin,
        }
    
    # =========================================================================
    # MAIN PROCESSING
    # =========================================================================
    
    def compute_features(self, match: pd.Series) -> Dict[str, Any]:
        """Compute all features for a single match."""
        date = pd.to_datetime(match['date'])
        home, away = match['home_team'], match['away_team']
        
        home_hist = self._get_team_history(home, date)
        away_hist = self._get_team_history(away, date)
        
        features = {
            'match_id': match.get('match_id', ''),
        }
        
        # Layer 1: Fundamentals
        features.update(self._compute_elo(home, away, date))
        features.update(self._compute_pythagorean(home_hist, away_hist))
        
        # Layer 2: Rolling
        for w in config.rolling_windows:
            features.update(self._compute_rolling(home_hist, w, 'home'))
            features.update(self._compute_rolling(away_hist, w, 'away'))
        
        # Layer 3: Context
        venue = match.get('venue') if 'venue' in match.index else None
        features.update(self._compute_hga(home, away, venue))
        features.update(self._compute_fatigue(home_hist, away_hist, date))
        
        # Layer 4: Matchups
        features.update(self._compute_h2h(home, away, date))
        
        # Layer 5: Volatility
        features.update(self._compute_volatility(home_hist, away_hist))
        features.update(self._compute_momentum(home_hist, 'home'))
        features.update(self._compute_momentum(away_hist, 'away'))
        
        referee = match.get('referee') if 'referee' in match.index else None
        features.update(self._compute_referee(referee, date))
        
        # Market
        home_odds = match.get('home_odds_close') if 'home_odds_close' in match.index else None
        away_odds = match.get('away_odds_close') if 'away_odds_close' in match.index else None
        features.update(self._compute_market(home_odds, away_odds))
        
        # Add feature version
        features['feature_version'] = config.feature_version
        
        return features
    
    def process(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Process dataframe to add derived features.
        
        Args:
            df: Raw match data
        
        Returns:
            DataFrame with computed features
        """
        logger.info(f"⚙️ Engineering features for {len(df)} matches...")
        
        # If no historical data, use the input as historical
        if self.historical is None or self.historical.empty:
            self.historical = df.copy()
            self._prepare_historical()
        
        rows = []
        for _, match in df.iterrows():
            features = self.compute_features(match)
            rows.append(features)
        
        features_df = pd.DataFrame(rows)
        
        # Merge with original data
        result = df.merge(features_df, on='match_id', how='left')
        
        logger.info(f"✅ Features computed: {len(features_df.columns)} columns")
        return result
    
    def get_feature_columns(self, df: pd.DataFrame) -> List[str]:
        """Get list of feature columns for modeling."""
        exclude = config.feature_exclude
        
        return [
            col for col in df.columns
            if col not in exclude
            and df[col].dtype in ['float64', 'int64', 'float32', 'int32']
        ]
