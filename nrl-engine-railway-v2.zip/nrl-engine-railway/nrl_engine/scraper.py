"""
NRL Data Scraper - Production Ready

Multi-source scraper for NRL match data:
1. Rugby League Project (RLP) - Primary source for results, venues, referees
2. NRL.com Match Centre - For detailed match statistics  
3. beauhobba/NRL-Data S3 - Pre-scraped historical data

All sources are public domain - no authentication required.
"""
import pandas as pd
import requests
from bs4 import BeautifulSoup
import re
import time
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass

from nrl_engine.config import config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# =============================================================================
# TEAM NAME MAPPINGS
# =============================================================================

CANONICAL_TEAMS = [
    "Brisbane Broncos", "Canberra Raiders", "Canterbury Bulldogs",
    "Cronulla Sharks", "Dolphins", "Gold Coast Titans", "Manly Sea Eagles",
    "Melbourne Storm", "Newcastle Knights", "North Queensland Cowboys",
    "New Zealand Warriors", "Parramatta Eels", "Penrith Panthers",
    "South Sydney Rabbitohs", "St George Illawarra Dragons",
    "Sydney Roosters", "Wests Tigers",
]

TEAM_ALIASES = {
    "broncos": "Brisbane Broncos", "brisbane": "Brisbane Broncos",
    "raiders": "Canberra Raiders", "canberra": "Canberra Raiders",
    "bulldogs": "Canterbury Bulldogs", "canterbury": "Canterbury Bulldogs",
    "sharks": "Cronulla Sharks", "cronulla": "Cronulla Sharks",
    "dolphins": "Dolphins", "redcliffe": "Dolphins",
    "titans": "Gold Coast Titans", "gold coast": "Gold Coast Titans",
    "sea eagles": "Manly Sea Eagles", "manly": "Manly Sea Eagles",
    "storm": "Melbourne Storm", "melbourne": "Melbourne Storm",
    "knights": "Newcastle Knights", "newcastle": "Newcastle Knights",
    "cowboys": "North Queensland Cowboys", "north queensland": "North Queensland Cowboys",
    "north qld": "North Queensland Cowboys", "nth qld": "North Queensland Cowboys",
    "warriors": "New Zealand Warriors", "new zealand": "New Zealand Warriors",
    "eels": "Parramatta Eels", "parramatta": "Parramatta Eels",
    "panthers": "Penrith Panthers", "penrith": "Penrith Panthers",
    "rabbitohs": "South Sydney Rabbitohs", "south sydney": "South Sydney Rabbitohs",
    "souths": "South Sydney Rabbitohs",
    "dragons": "St George Illawarra Dragons", "st george": "St George Illawarra Dragons",
    "st geo illa": "St George Illawarra Dragons",
    "roosters": "Sydney Roosters", "sydney": "Sydney Roosters",
    "tigers": "Wests Tigers", "wests tigers": "Wests Tigers", "wests": "Wests Tigers",
}

VENUE_ALIASES = {
    "suncorp": "Suncorp Stadium", "suncorp stadium": "Suncorp Stadium",
    "accor": "Accor Stadium", "accor stadium": "Accor Stadium",
    "stadium australia": "Accor Stadium",
    "aami": "AAMI Park", "aami park": "AAMI Park",
    "commbank": "CommBank Stadium", "commbank stadium": "CommBank Stadium",
    "4 pines": "4 Pines Park", "4 pines park": "4 Pines Park",
    "brookvale": "4 Pines Park",
    "bluebet": "BlueBet Stadium", "bluebet stadium": "BlueBet Stadium",
    "pointsbet": "PointsBet Stadium", "pointsbet stadium": "PointsBet Stadium",
    "sharks": "PointsBet Stadium",
    "mcdonald jones": "McDonald Jones Stadium", "mcd. jones": "McDonald Jones Stadium",
    "qld country bank": "Queensland Country Bank Stadium",
    "cbus": "Cbus Super Stadium", "cbus super stadium": "Cbus Super Stadium",
    "go media": "Go Media Stadium", "go media stadium": "Go Media Stadium",
    "mt smart": "Go Media Stadium",
    "gio": "GIO Stadium", "gio stadium": "GIO Stadium",
    "win": "WIN Stadium", "win stadium": "WIN Stadium",
    "netstrata": "Netstrata Jubilee Stadium", "kogarah": "Netstrata Jubilee Stadium",
    "campbelltown": "Campbelltown Stadium",
    "leichhardt": "Leichhardt Oval", "leichhardt oval": "Leichhardt Oval",
    "allianz": "Allianz Stadium", "allianz stadium": "Allianz Stadium",
}


def normalize_team(name: str) -> str:
    """Normalize team name to canonical format."""
    if not name:
        return name
    
    name_clean = name.lower().strip()
    name_clean = re.sub(r'\s+', ' ', name_clean)
    
    if name_clean in TEAM_ALIASES:
        return TEAM_ALIASES[name_clean]
    
    for canonical in CANONICAL_TEAMS:
        if name.strip() == canonical or canonical.lower() == name_clean:
            return canonical
    
    for alias, canonical in TEAM_ALIASES.items():
        if alias in name_clean or name_clean in alias:
            return canonical
    
    logger.warning(f"Unknown team name: {name}")
    return name.strip()


def normalize_venue(name: str) -> str:
    """Normalize venue name."""
    if not name:
        return name
    
    name_clean = name.lower().strip()
    
    if name_clean in VENUE_ALIASES:
        return VENUE_ALIASES[name_clean]
    
    for alias, canonical in VENUE_ALIASES.items():
        if alias in name_clean:
            return canonical
    
    return name.strip()


# =============================================================================
# SCRAPER CLASS
# =============================================================================

@dataclass
class ScraperConfig:
    """Configuration for scraper behavior."""
    timeout: int = 30
    retries: int = 3
    delay: float = 2.0
    user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"


class NRLScraper:
    """
    Multi-source NRL data scraper.
    
    Sources:
    - Rugby League Project (results, fixtures, referees)
    - NRL.com (detailed match stats)
    """
    
    RLP_BASE = "https://www.rugbyleagueproject.org"
    NRL_BASE = "https://www.nrl.com"
    
    def __init__(self, scraper_config: Optional[ScraperConfig] = None):
        self.config = scraper_config or ScraperConfig(
            timeout=config.scraper_timeout,
            retries=config.scraper_retries,
            delay=config.scraper_delay,
        )
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': self.config.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
        })
    
    def _request(self, url: str, retries: Optional[int] = None) -> Optional[requests.Response]:
        """Make HTTP request with retry logic."""
        retries = retries or self.config.retries
        
        for attempt in range(retries):
            try:
                response = self.session.get(url, timeout=self.config.timeout)
                response.raise_for_status()
                time.sleep(self.config.delay)
                return response
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{retries}): {e}")
                if attempt < retries - 1:
                    time.sleep(5 * (attempt + 1))
        
        return None
    
    # =========================================================================
    # RUGBY LEAGUE PROJECT SCRAPER
    # =========================================================================
    
    def scrape_rlp_season_summary(self, season: int) -> pd.DataFrame:
        """
        Scrape season summary from Rugby League Project.
        
        Parses the summary page which has ladder and finals results.
        """
        logger.info(f"🕵️ Scraping RLP season {season} summary...")
        
        url = f"{self.RLP_BASE}/seasons/nrl-{season}/summary.html"
        response = self._request(url)
        
        if not response:
            logger.error(f"Failed to fetch RLP season {season}")
            return pd.DataFrame()
        
        soup = BeautifulSoup(response.content, 'lxml')
        matches = []
        
        # Parse finals/playoffs table
        # Look for tables with match results
        tables = soup.find_all('table')
        
        for table in tables:
            rows = table.find_all('tr')
            for row in rows:
                cells = row.find_all('td')
                if len(cells) >= 5:
                    match = self._parse_summary_row(cells, season)
                    if match:
                        matches.append(match)
        
        df = pd.DataFrame(matches)
        
        if not df.empty:
            df['season'] = season
            logger.info(f"✅ Scraped {len(df)} matches from RLP summary for {season}")
        
        return df
    
    def _parse_summary_row(self, cells, season: int) -> Optional[Dict]:
        """Parse a row from the RLP summary/finals table."""
        try:
            # Extract text from cells
            cell_texts = [cell.get_text(strip=True) for cell in cells]
            
            # Look for team names (links)
            team_links = []
            for cell in cells:
                links = cell.find_all('a', href=re.compile(r'/seasons/nrl-\d+/[a-z-]+/'))
                team_links.extend(links)
            
            if len(team_links) < 2:
                return None
            
            home_team = normalize_team(team_links[0].text)
            away_team = normalize_team(team_links[1].text)
            
            # Find scores - look for pattern "Team XX Team YY"
            row_text = ' '.join(cell_texts)
            score_pattern = r'(\d{1,2})\s+(?:' + re.escape(away_team.split()[0]) + r'|[A-Z])'
            scores = re.findall(r'(\d{1,2})', row_text)
            
            if len(scores) >= 2:
                home_score = int(scores[0])
                away_score = int(scores[1])
            else:
                return None
            
            # Find venue
            venue = None
            for cell in cells:
                venue_link = cell.find('a', href=re.compile(r'/venues/'))
                if venue_link:
                    venue = normalize_venue(venue_link.text)
                    break
            
            # Find referee
            referee = None
            for cell in cells:
                ref_link = cell.find('a', href=re.compile(r'/referees/'))
                if ref_link:
                    referee = ref_link.text.strip()
                    break
            
            # Find date
            date_match = re.search(r'([A-Z][a-z]{2})\s+(\d{1,2})', row_text)
            if date_match:
                month_map = {'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
                             'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12}
                month = month_map.get(date_match.group(1), 1)
                day = int(date_match.group(2))
                match_date = datetime(season, month, day)
            else:
                match_date = datetime(season, 1, 1)
            
            # Find round
            round_match = re.search(r'(Round\s+\d+|Qualif|Elim|Semi|Prelim|Grand)\s*Final?', row_text, re.I)
            round_name = round_match.group(0) if round_match else "Unknown"
            
            match_id = f"{season}_{round_name.replace(' ', '')}_{home_team[:3]}v{away_team[:3]}"
            
            return {
                'match_id': match_id,
                'date': match_date,
                'round': round_name,
                'home_team': home_team,
                'away_team': away_team,
                'home_score': home_score,
                'away_score': away_score,
                'venue': venue,
                'referee': referee,
            }
        except Exception as e:
            logger.debug(f"Error parsing row: {e}")
            return None
    
    def scrape_rlp_round(self, season: int, round_num: int) -> List[Dict]:
        """
        Scrape a single round from Rugby League Project.
        """
        logger.info(f"  Scraping {season} Round {round_num}...")
        
        url = f"{self.RLP_BASE}/seasons/nrl-{season}/round-{round_num}/summary.html"
        response = self._request(url)
        
        if not response:
            return []
        
        soup = BeautifulSoup(response.content, 'lxml')
        matches = []
        
        # RLP format includes match results in text
        # Pattern: "Team A NN (scorers) defeated Team B NN (scorers) at Venue"
        
        # Get page text
        page_text = soup.get_text()
        
        # Split into match blocks (each starts with > or View)
        match_blocks = re.split(r'(?:>|View)\s+', page_text)
        
        for block in match_blocks:
            match = self._parse_rlp_match_block(block, season, round_num)
            if match:
                matches.append(match)
        
        return matches
    
    def _parse_rlp_match_block(self, block: str, season: int, round_num: int) -> Optional[Dict]:
        """Parse a match result block from RLP."""
        try:
            # Pattern: "Team A NN (scorers...) defeated/drew with Team B NN (scorers...) at Venue."
            # Followed by "Date: ...", "Referee: ..."
            
            # Extract main result line
            result_pattern = r'([A-Za-z\s]+?)\s+(\d+)\s+\([^)]+\)\s+(defeated|drew with|lost to)\s+([A-Za-z\s]+?)\s+(\d+)\s+\([^)]+\)\s+at\s+([^.]+)'
            
            result_match = re.search(result_pattern, block)
            
            if not result_match:
                # Try simpler pattern without scorers
                simple_pattern = r'([A-Za-z\s]+?)\s+(\d+)\s+(defeated|drew with)\s+([A-Za-z\s]+?)\s+(\d+)\s+at\s+([^.]+)'
                result_match = re.search(simple_pattern, block)
            
            if not result_match:
                return None
            
            home_team = normalize_team(result_match.group(1).strip())
            home_score = int(result_match.group(2))
            away_team = normalize_team(result_match.group(4).strip())
            away_score = int(result_match.group(5))
            venue = normalize_venue(result_match.group(6).strip())
            
            # Check we got valid teams
            if home_team not in CANONICAL_TEAMS or away_team not in CANONICAL_TEAMS:
                return None
            
            # Extract date
            date_match = re.search(r'Date:\s*([A-Za-z]+,?\s*\d+[a-z]*\s+[A-Za-z]+)', block)
            if date_match:
                match_date = self._parse_rlp_date(date_match.group(1), season)
            else:
                match_date = datetime(season, 3, 1) + timedelta(weeks=round_num-1)
            
            # Extract referee
            ref_match = re.search(r'Referee:\s*([A-Za-z\s]+?)\.', block)
            referee = ref_match.group(1).strip() if ref_match else None
            
            # Extract penalties (basic discipline metric)
            pen_match = re.search(r'Penalties:\s*[A-Za-z]+\s+(\d+)-(\d+)', block)
            if pen_match:
                # Determine which team is which based on order
                # Usually "Home X-Y" format
                home_penalties = int(pen_match.group(1))
                away_penalties = int(pen_match.group(2))
            else:
                home_penalties = None
                away_penalties = None
            
            # Extract crowd
            crowd_match = re.search(r'Crowd:\s*([\d,]+)', block)
            crowd = int(crowd_match.group(1).replace(',', '')) if crowd_match else None
            
            match_id = f"{season}_R{round_num}_{home_team[:3]}v{away_team[:3]}"
            
            return {
                'match_id': match_id,
                'date': match_date,
                'season': season,
                'round': f"Round {round_num}",
                'home_team': home_team,
                'away_team': away_team,
                'home_score': home_score,
                'away_score': away_score,
                'venue': venue,
                'referee': referee,
                'home_penalties': home_penalties,
                'away_penalties': away_penalties,
                'crowd': crowd,
            }
        except Exception as e:
            logger.debug(f"Error parsing match block: {e}")
            return None
    
    def _parse_rlp_date(self, date_str: str, season: int) -> datetime:
        """Parse RLP date format."""
        try:
            # Remove ordinal suffixes
            date_clean = re.sub(r'(\d+)(st|nd|rd|th)', r'\1', date_str)
            date_clean = date_clean.replace(',', '')
            
            for fmt in ['%a %d %B', '%A %d %B', '%d %B']:
                try:
                    dt = datetime.strptime(date_clean.strip(), fmt)
                    return dt.replace(year=season)
                except ValueError:
                    continue
            
            return datetime(season, 1, 1)
        except Exception:
            return datetime(season, 1, 1)
    
    def scrape_season(self, season: int) -> pd.DataFrame:
        """Scrape all matches for a season."""
        logger.info(f"🕵️ Scraping full season {season}...")
        
        all_matches = []
        
        # Scrape regular season rounds (1-27)
        for round_num in range(1, 28):
            matches = self.scrape_rlp_round(season, round_num)
            all_matches.extend(matches)
            
            # If we get empty results for several rounds, stop
            if round_num > 5 and not matches:
                consecutive_empty = sum(1 for i in range(max(1, round_num-3), round_num+1)
                                       if not self.scrape_rlp_round(season, i))
                if consecutive_empty >= 3:
                    break
        
        # Also get summary data (includes finals)
        summary_df = self.scrape_rlp_season_summary(season)
        if not summary_df.empty:
            summary_matches = summary_df.to_dict('records')
            
            # Add finals matches not already captured
            existing_ids = {m['match_id'] for m in all_matches}
            for match in summary_matches:
                if match.get('match_id') not in existing_ids:
                    all_matches.append(match)
        
        df = pd.DataFrame(all_matches)
        
        if not df.empty:
            df['date'] = pd.to_datetime(df['date'], errors='coerce')
            df['season'] = season
            df = df.drop_duplicates(subset=['match_id'])
            logger.info(f"✅ Scraped {len(df)} total matches for {season}")
        
        return df
    
    # =========================================================================
    # MAIN SCRAPING METHODS
    # =========================================================================
    
    def scrape_latest_round(self) -> pd.DataFrame:
        """Scrape the most recent completed round."""
        logger.info("🕵️ Scraping latest round...")
        
        today = datetime.now()
        season = today.year if today.month >= 3 else today.year - 1
        
        # Estimate current round
        season_start = datetime(season, 3, 1)
        weeks_elapsed = (today - season_start).days // 7
        estimated_round = min(max(1, weeks_elapsed), 27)
        
        all_matches = []
        
        # Try current and recent rounds
        for round_offset in [0, -1, -2]:
            round_num = estimated_round + round_offset
            if 1 <= round_num <= 27:
                matches = self.scrape_rlp_round(season, round_num)
                all_matches.extend(matches)
        
        if all_matches:
            df = pd.DataFrame(all_matches)
            df['date'] = pd.to_datetime(df['date'], errors='coerce')
            df = df.drop_duplicates(subset=['match_id'])
            logger.info(f"✅ Scraped {len(df)} recent matches")
            return df
        
        logger.warning("Could not scrape live data, using mock data")
        return self._generate_mock_data()
    
    def scrape_historical(self, start_year: int, end_year: int) -> pd.DataFrame:
        """Scrape historical data for multiple seasons."""
        all_data = []
        
        for year in range(start_year, end_year + 1):
            try:
                df = self.scrape_season(year)
                if not df.empty:
                    all_data.append(df)
            except Exception as e:
                logger.error(f"Failed to scrape {year}: {e}")
        
        if all_data:
            result = pd.concat(all_data, ignore_index=True)
            result = result.drop_duplicates(subset=['match_id'])
            logger.info(f"✅ Total scraped: {len(result)} matches")
            return result
        
        return pd.DataFrame()
    
    def _generate_mock_data(self) -> pd.DataFrame:
        """Generate realistic mock data for testing."""
        today = datetime.now().date()
        season = today.year if today.month >= 3 else today.year - 1
        
        matches = [
            {
                "match_id": f"{season}_R1_BRIvSYD",
                "date": today - timedelta(days=4),
                "season": season,
                "round": "Round 1",
                "venue": "Suncorp Stadium",
                "home_team": "Brisbane Broncos",
                "away_team": "Sydney Roosters",
                "home_score": 24,
                "away_score": 18,
                "home_odds_close": 1.85,
                "away_odds_close": 2.00,
                "home_possession_pct": 52.0,
                "away_possession_pct": 48.0,
                "home_completion_rate": 82.0,
                "away_completion_rate": 78.0,
                "home_run_metres": 1650,
                "away_run_metres": 1520,
                "home_post_contact_metres": 520,
                "away_post_contact_metres": 480,
                "home_line_breaks": 5,
                "away_line_breaks": 4,
                "home_errors": 8,
                "away_errors": 11,
                "home_penalties": 5,
                "away_penalties": 7,
                "home_set_restarts": 3,
                "away_set_restarts": 4,
                "home_missed_tackles": 22,
                "away_missed_tackles": 28,
                "referee": "Ashley Klein"
            },
            {
                "match_id": f"{season}_R1_PENvCAN",
                "date": today - timedelta(days=3),
                "season": season,
                "round": "Round 1",
                "venue": "BlueBet Stadium",
                "home_team": "Penrith Panthers",
                "away_team": "Canterbury Bulldogs",
                "home_score": 32,
                "away_score": 12,
                "home_odds_close": 1.25,
                "away_odds_close": 4.20,
                "home_possession_pct": 55.0,
                "away_possession_pct": 45.0,
                "home_completion_rate": 85.0,
                "away_completion_rate": 72.0,
                "home_run_metres": 1780,
                "away_run_metres": 1380,
                "home_post_contact_metres": 580,
                "away_post_contact_metres": 420,
                "home_line_breaks": 7,
                "away_line_breaks": 2,
                "home_errors": 6,
                "away_errors": 14,
                "home_penalties": 4,
                "away_penalties": 8,
                "home_set_restarts": 2,
                "away_set_restarts": 6,
                "home_missed_tackles": 18,
                "away_missed_tackles": 35,
                "referee": "Gerard Sutton"
            },
            {
                "match_id": f"{season}_R1_MELvMAN",
                "date": today - timedelta(days=3),
                "season": season,
                "round": "Round 1",
                "venue": "AAMI Park",
                "home_team": "Melbourne Storm",
                "away_team": "Manly Sea Eagles",
                "home_score": 28,
                "away_score": 24,
                "home_odds_close": 1.55,
                "away_odds_close": 2.55,
                "home_possession_pct": 48.0,
                "away_possession_pct": 52.0,
                "home_completion_rate": 80.0,
                "away_completion_rate": 76.0,
                "home_run_metres": 1450,
                "away_run_metres": 1580,
                "home_post_contact_metres": 460,
                "away_post_contact_metres": 510,
                "home_line_breaks": 4,
                "away_line_breaks": 5,
                "home_errors": 10,
                "away_errors": 9,
                "home_penalties": 6,
                "away_penalties": 5,
                "home_set_restarts": 4,
                "away_set_restarts": 3,
                "home_missed_tackles": 25,
                "away_missed_tackles": 24,
                "referee": "Grant Atkins"
            },
            {
                "match_id": f"{season}_R1_CROvNQL",
                "date": today - timedelta(days=2),
                "season": season,
                "round": "Round 1",
                "venue": "PointsBet Stadium",
                "home_team": "Cronulla Sharks",
                "away_team": "North Queensland Cowboys",
                "home_score": 18,
                "away_score": 22,
                "home_odds_close": 1.75,
                "away_odds_close": 2.15,
                "home_possession_pct": 46.0,
                "away_possession_pct": 54.0,
                "home_completion_rate": 75.0,
                "away_completion_rate": 81.0,
                "home_run_metres": 1420,
                "away_run_metres": 1620,
                "home_post_contact_metres": 440,
                "away_post_contact_metres": 520,
                "home_line_breaks": 3,
                "away_line_breaks": 5,
                "home_errors": 12,
                "away_errors": 7,
                "home_penalties": 7,
                "away_penalties": 6,
                "home_set_restarts": 5,
                "away_set_restarts": 3,
                "home_missed_tackles": 30,
                "away_missed_tackles": 22,
                "referee": "Adam Gee"
            },
            {
                "match_id": f"{season}_R1_PARvGLD",
                "date": today - timedelta(days=2),
                "season": season,
                "round": "Round 1",
                "venue": "CommBank Stadium",
                "home_team": "Parramatta Eels",
                "away_team": "Gold Coast Titans",
                "home_score": 16,
                "away_score": 20,
                "home_odds_close": 1.65,
                "away_odds_close": 2.30,
                "home_possession_pct": 51.0,
                "away_possession_pct": 49.0,
                "home_completion_rate": 74.0,
                "away_completion_rate": 79.0,
                "home_run_metres": 1480,
                "away_run_metres": 1550,
                "home_post_contact_metres": 470,
                "away_post_contact_metres": 490,
                "home_line_breaks": 3,
                "away_line_breaks": 4,
                "home_errors": 13,
                "away_errors": 9,
                "home_penalties": 6,
                "away_penalties": 5,
                "home_set_restarts": 4,
                "away_set_restarts": 3,
                "home_missed_tackles": 28,
                "away_missed_tackles": 26,
                "referee": "Ben Cummins"
            },
        ]
        
        df = pd.DataFrame(matches)
        df['date'] = pd.to_datetime(df['date'])
        
        logger.info(f"✅ Generated {len(df)} mock matches for testing")
        return df
    
    def get_referee_list(self) -> List[str]:
        """Get list of current NRL referees."""
        return [
            "Ashley Klein", "Gerard Sutton", "Grant Atkins", "Adam Gee",
            "Ben Cummins", "Todd Smith", "Peter Gough", "Chris Butler",
            "Liam Kennedy", "Kasey Badger", "Chris Sutton", "Darian Furner",
        ]


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def run_scraper() -> pd.DataFrame:
    """Main entry point for scraping latest data."""
    scraper = NRLScraper()
    return scraper.scrape_latest_round()


def scrape_season(season: int) -> pd.DataFrame:
    """Scrape a single season."""
    scraper = NRLScraper()
    return scraper.scrape_season(season)


def scrape_historical(start_year: int, end_year: int) -> pd.DataFrame:
    """Scrape multiple seasons."""
    scraper = NRLScraper()
    return scraper.scrape_historical(start_year, end_year)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="NRL Data Scraper")
    parser.add_argument("--season", type=int, help="Scrape specific season")
    parser.add_argument("--latest", action="store_true", help="Scrape latest round")
    parser.add_argument("--historical", nargs=2, type=int, metavar=('START', 'END'),
                        help="Scrape historical range")
    parser.add_argument("--output", type=str, default="matches.csv", help="Output file")
    
    args = parser.parse_args()
    
    scraper = NRLScraper()
    
    if args.season:
        df = scraper.scrape_season(args.season)
    elif args.historical:
        df = scraper.scrape_historical(args.historical[0], args.historical[1])
    else:
        df = scraper.scrape_latest_round()
    
    if not df.empty:
        df.to_csv(args.output, index=False)
        print(f"Saved {len(df)} matches to {args.output}")
    else:
        print("No data scraped")
