# NRL Engine 🏉

A comprehensive NRL (National Rugby League) prediction engine with automated data scraping, feature engineering, and PostgreSQL storage. Designed for deployment on Railway.

## Features

- **Automated Scraping**: Fetches match data from NRL.com and Rugby League Project
- **5-Layer Feature Engineering**: 
  - Layer 1: Fundamentals (ELO, Pythagorean Expectation)
  - Layer 2: Personnel (Squad strength, VORP proxies)
  - Layer 3: Context (Home Ground Advantage, Fatigue, Travel)
  - Layer 4: Stylistic (Attack/Defense matchups, H2H)
  - Layer 5: Volatility (Referee tendencies, Momentum)
- **Market Analysis**: Reverse-engineering betting odds for implied probabilities
- **Scheduled Execution**: Automatic weekly updates on Tuesday and Sunday

## Deployment on Railway

### 1. Create Repository

```bash
# Clone or create new repo
git clone https://github.com/YOUR_USERNAME/nrl-engine.git
cd nrl-engine

# Copy files from this template
# ... (copy all files)

# Push to GitHub
git add .
git commit -m "Initial NRL Engine setup"
git push origin main
```

### 2. Deploy on Railway

1. Go to [Railway](https://railway.app) and create new project
2. Select "Deploy from GitHub repo"
3. Choose your nrl-engine repository
4. Railway will detect the Procfile and deploy automatically

### 3. Add PostgreSQL Database

1. In your Railway project, click "New" → "Database" → "PostgreSQL"
2. Railway automatically injects `DATABASE_URL` environment variable
3. The app will create tables on first startup

### 4. Environment Variables

Railway auto-injects `DATABASE_URL`. Optionally set:

| Variable | Default | Description |
|----------|---------|-------------|
| `ENV` | `production` | Environment mode |
| `DEBUG` | `false` | Enable debug logging |
| `SCRAPE_DAY` | `tuesday` | Primary scrape day |
| `SCRAPE_TIME` | `22:00` | Scrape time (UTC) |

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Railway Worker                        │
│                                                          │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐          │
│  │ Scraper  │───▶│ Engineer │───▶│ Database │          │
│  │ (NRL.com)│    │ (5-Layer)│    │ (Postgres)│          │
│  └──────────┘    └──────────┘    └──────────┘          │
│       │                │                │               │
│       └────────────────┴────────────────┘               │
│                        │                                │
│                  ┌─────▼─────┐                          │
│                  │ Scheduler │                          │
│                  │ (Weekly)  │                          │
│                  └───────────┘                          │
└─────────────────────────────────────────────────────────┘
```

## Feature Vectors

### Layer 1: Fundamentals
- `home_elo`, `away_elo`: Dynamic team strength ratings
- `elo_diff`: Rating differential + home advantage
- `home_pythag`: Pythagorean win expectation

### Layer 2: Rolling Form
- `home_{n}_win_rate`: Win rate over last n games
- `home_{n}_margin`: Average margin over last n games
- `home_{n}_pf`, `home_{n}_pa`: Points for/against

### Layer 3: Context
- `home_rest_days`: Days since last game
- `fatigue_advantage`: Net rest advantage
- `adjusted_hga`: Venue-specific home advantage

### Layer 4: Matchups
- `h2h_home_win_rate`: Historical head-to-head
- `h2h_margin`: Average margin in previous meetings

### Layer 5: Volatility
- `home_volatility`: Scoring variance (σ)
- `home_momentum`: Form momentum (0-100)
- `ref_home_bias`: Referee tendency toward home teams

### Market Vectors
- `market_home_fair`: De-vigged implied probability
- `market_implied_margin`: Spread derived from odds

## Database Schema

### Tables
- `match_stats`: Raw match data and statistics
- `match_features`: Computed feature vectors
- `predictions`: Model predictions
- `elo_history`: ELO rating snapshots
- `referee_stats`: Aggregated referee statistics

## Local Development

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set up local database
export DATABASE_URL="postgresql://user:pass@localhost:5432/nrl"

# Run
python main.py
```

## Testing

```bash
# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=nrl_engine
```

## Project Structure

```
nrl-engine/
├── main.py              # Entry point (scheduler)
├── Procfile             # Railway process definition
├── requirements.txt     # Python dependencies
├── .gitignore
├── .env.example
├── README.md
└── nrl_engine/
    ├── __init__.py
    ├── config.py        # Configuration settings
    ├── db.py            # Database operations
    ├── scraper.py       # Data collection
    ├── engineer.py      # Feature engineering
    └── schema.py        # Data validation
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes
4. Run tests
5. Submit PR

## License

MIT License - See LICENSE file for details.

## Acknowledgments

- NRL.com for public match data
- Rugby League Project for historical statistics
- "Vectorized Advantage" framework for feature engineering methodology
