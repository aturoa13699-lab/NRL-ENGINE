"""Model definitions."""

from nrl_engine.models.baseline import create_baseline_model

__all__ = ["create_baseline_model"]
