"""
NRL Engine - Rugby League Prediction Framework

A comprehensive system for:
- Scraping NRL match data from public sources
- Engineering predictive features (ELO, Pythagorean, HGA, etc.)
- Storing data in PostgreSQL
- Generating match predictions

Deployed on Railway with scheduled weekly updates.
"""

__version__ = "3.0.0"
__author__ = "NRL Engine"

from nrl_engine.config import config
from nrl_engine.engineer import FeatureEngineer
from nrl_engine.scraper import NRLScraper, run_scraper
from nrl_engine.schema import DataValidator

__all__ = [
    "config",
    "FeatureEngineer",
    "NRLScraper",
    "run_scraper",
    "DataValidator",
]
