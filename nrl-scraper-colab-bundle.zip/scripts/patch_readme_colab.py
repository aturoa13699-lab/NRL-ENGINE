
import re, sys, os

BADGES = """<!-- COLAB:START -->
## Colab

Open any of these notebooks directly in Colab:

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USER/REPO/blob/main/notebooks/00_colab_bootstrap.ipynb)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USER/REPO/blob/main/notebooks/10_eda_baseline.ipynb)
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USER/REPO/blob/main/notebooks/20_model_baseline.ipynb)

<!-- COLAB:END -->
"""

def main():
    if len(sys.argv) < 4:
        print("Usage: python scripts/patch_readme_colab.py USER REPO [README.md]")
        sys.exit(2)
    user, repo = sys.argv[1], sys.argv[2]
    path = sys.argv[3] if len(sys.argv) >= 4 else "README.md"
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write("")
    with open(path, "r", encoding="utf-8") as f:
        s = f.read()
    block = BADGES.replace("USER", user).replace("REPO", repo)
    if "<!-- COLAB:START -->" in s:
        s = re.sub(r"<!-- COLAB:START -->.*?<!-- COLAB:END -->", block, s, flags=re.S)
    elif "<!-- LINKS:END -->" in s:
        s = s.replace("<!-- LINKS:END -->", "<!-- LINKS:END -->\\n\\n" + block)
    elif "<!-- BADGES:END -->" in s:
        s = s.replace("<!-- BADGES:END -->", "<!-- BADGES:END -->\\n\\n" + block)
    else:
        s = block + "\\n\\n" + s
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)
    print("Patched", path)

if __name__ == "__main__":
    main()
