"""Tests for NRL Scraper."""
