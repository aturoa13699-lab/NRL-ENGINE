#!/usr/bin/env bash
set -euo pipefail
USER="${1:?GitHub username required}"
REPO="${2:?Repo name required}"
EMAIL="${3:-you@example.com}"
BRANCH="${4:-reports}"
TOKEN="${GITHUB_TOKEN:-}"
if [[ -z "${TOKEN}" ]]; then
  echo "Set GITHUB_TOKEN env var (fine-grained, contents:write)"
  exit 2
fi
REMOTE="https://${USER}:${TOKEN}@github.com/${USER}/${REPO}.git"
git config user.name "${USER}"
git config user.email "${EMAIL}"
git checkout -B "${BRANCH}"
git add reports/*.html || true
git add notebooks/*.ipynb || true
git commit -m "docs(reports): update Colab HTML reports" || true
git push -f "${REMOTE}" "${BRANCH}:${BRANCH}"
echo "Pushed to ${BRANCH}"
