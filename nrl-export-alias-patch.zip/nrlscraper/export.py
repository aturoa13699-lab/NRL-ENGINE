from pathlib import Path
import pandas as pd
from .config import settings

__all__ = ["to_parquet", "export_to_parquet"]

def to_parquet(rows: list[dict], table: str, season: int) -> str:
    """Write rows to a partitioned Parquet path.
    Returns the written file path.
    """
    df = pd.DataFrame(rows)
    out_dir = Path(settings.exports_dir) / table / f"season={season}"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "part-000.parquet"
    df.to_parquet(out_path, index=False)
    (out_dir / "_manifest.json").write_text('{"version":"1","table":"%s"}' % table)
    return str(out_path)

# Backward-compatible alias expected by some callers
def export_to_parquet(rows: list[dict], table: str, season: int) -> str:
    return to_parquet(rows, table, season)
