"""
NRL Engine - Main Entry Point (Railway Worker)

This is the scheduler that runs continuously on Railway.
It orchestrates:
1. Weekly data scraping (Tuesday + Sunday)
2. Feature engineering
3. Database storage
4. Model predictions (when matches available)

Railway runs this as a worker process.
"""
import time
import sys
import logging
import schedule
from datetime import datetime

from nrl_engine.config import config
from nrl_engine.db import init_db, save_matches, save_features, load_matches
from nrl_engine.scraper import run_scraper
from nrl_engine.engineer import FeatureEngineer
from nrl_engine.schema import DataValidator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


def run_pipeline():
    """
    Main pipeline job.
    
    1. Scrape latest data
    2. Validate data
    3. Engineer features
    4. Save to database
    """
    job_start = datetime.now()
    logger.info(f"🚀 Starting Pipeline Job at {job_start.isoformat()}")
    
    try:
        # Step 1: Scrape
        logger.info("Step 1/4: Scraping latest data...")
        raw_df = run_scraper()
        
        if raw_df.empty:
            logger.warning("⚠️ No data scraped. Exiting pipeline.")
            return
        
        logger.info(f"   Scraped {len(raw_df)} matches")
        
        # Step 2: Validate
        logger.info("Step 2/4: Validating data...")
        is_valid = DataValidator.report(raw_df)
        
        if not is_valid:
            logger.error("❌ Data validation failed. Aborting.")
            return
        
        # Step 3: Engineer Features
        logger.info("Step 3/4: Engineering features...")
        
        # Load historical data for feature computation
        try:
            historical = load_matches()
            logger.info(f"   Loaded {len(historical)} historical matches")
        except Exception as e:
            logger.warning(f"   Could not load historical data: {e}")
            historical = None
        
        engineer = FeatureEngineer(historical_data=historical)
        processed_df = engineer.process(raw_df)
        
        logger.info(f"   Engineered {len(processed_df.columns)} features")
        
        # Step 4: Save to Database
        logger.info("Step 4/4: Saving to database...")
        
        # Save raw match data
        saved = save_matches(processed_df)
        logger.info(f"   Saved {saved} matches to database")
        
        # Calculate job duration
        job_end = datetime.now()
        duration = (job_end - job_start).total_seconds()
        
        logger.info(f"✅ Pipeline completed successfully in {duration:.1f}s")
        logger.info(f"   Processed: {len(raw_df)} matches")
        logger.info(f"   Features: {len(engineer.get_feature_columns(processed_df))}")
        
    except Exception as e:
        logger.error(f"🔥 PIPELINE FAILED: {e}", exc_info=True)


def run_startup_check():
    """Run a quick pipeline on startup to verify everything works."""
    logger.info("🔍 Running startup check...")
    
    try:
        # Test database connection
        init_db()
        
        # Test scraper
        from nrl_engine.scraper import NRLScraper
        scraper = NRLScraper()
        _ = scraper._generate_mock_data()
        
        logger.info("✅ Startup check passed")
        return True
        
    except Exception as e:
        logger.error(f"❌ Startup check failed: {e}", exc_info=True)
        return False


def main():
    """Main entry point."""
    print("=" * 60)
    print("NRL ENGINE v3.0 (Railway Edition)")
    print("=" * 60)
    print(f"Environment: {config.ENV}")
    print(f"Schedule: {config.SCRAPE_DAY} @ {config.SCRAPE_TIME} UTC")
    print(f"          {config.SCRAPE_DAY_2} @ {config.SCRAPE_TIME_2} UTC")
    print("=" * 60)
    
    # Startup check
    if not run_startup_check():
        logger.error("Startup check failed. Check DATABASE_URL and dependencies.")
        # Don't exit - let Railway restart the service
        time.sleep(60)
        return main()
    
    # Schedule jobs
    # Primary: Tuesday evening UTC (Wednesday morning Sydney)
    schedule.every().tuesday.at(config.SCRAPE_TIME).do(run_pipeline)
    
    # Secondary: Sunday morning UTC (Sunday evening Sydney)
    schedule.every().sunday.at(config.SCRAPE_TIME_2).do(run_pipeline)
    
    # Also run immediately on deployment (for testing)
    if config.ENV == "development" or config.DEBUG:
        logger.info("📋 Running initial pipeline (dev mode)...")
        run_pipeline()
    
    logger.info(f"📅 Scheduler active. Next run: {schedule.next_run()}")
    
    # Main loop
    while True:
        try:
            schedule.run_pending()
            time.sleep(60)
        except KeyboardInterrupt:
            logger.info("Shutting down...")
            break
        except Exception as e:
            logger.error(f"Scheduler error: {e}", exc_info=True)
            time.sleep(60)


if __name__ == "__main__":
    main()
