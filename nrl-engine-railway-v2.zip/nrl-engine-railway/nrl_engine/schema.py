"""
Data Schema Validator.

Ensures scraped data meets requirements before processing.
Fails fast on critical issues, warns on quality problems.
"""
import pandas as pd
import numpy as np
from typing import Tuple, List, Dict, Optional
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class ValidationLevel(Enum):
    """Severity levels for validation issues."""
    CRITICAL = "CRITICAL"
    WARNING = "WARNING"
    INFO = "INFO"


@dataclass
class ValidationIssue:
    """A single validation issue."""
    level: ValidationLevel
    message: str
    column: Optional[str] = None
    count: Optional[int] = None


class DataValidator:
    """
    Validates match data integrity.
    
    Three validation levels:
    1. Structure: Required columns exist
    2. Types: Columns have expected data types
    3. Logic: Values are within reasonable ranges
    """
    
    # Critical columns (must exist)
    CRITICAL_COLS = {
        'match_id': {'nullable': False},
        'date': {'nullable': False},
        'home_team': {'nullable': False},
        'away_team': {'nullable': False},
        'home_score': {'nullable': False},
        'away_score': {'nullable': False},
    }
    
    # Important columns (warn if missing)
    IMPORTANT_COLS = [
        'home_odds_close', 'away_odds_close',
        'venue', 'round', 'referee',
    ]
    
    # Advanced stats (info if missing)
    ADVANCED_COLS = [
        'home_possession_pct', 'home_completion_rate',
        'home_run_metres', 'home_post_contact_metres',
        'home_line_breaks', 'home_tackle_breaks',
        'home_errors', 'home_penalties', 'home_set_restarts',
        'home_missed_tackles',
    ]
    
    # Value ranges for logic validation
    VALUE_RANGES = {
        'home_score': (0, 80),
        'away_score': (0, 80),
        'home_possession_pct': (20, 80),
        'away_possession_pct': (20, 80),
        'home_completion_rate': (40, 100),
        'away_completion_rate': (40, 100),
        'home_run_metres': (500, 2500),
        'away_run_metres': (500, 2500),
        'home_odds_close': (1.01, 20.0),
        'away_odds_close': (1.01, 20.0),
    }
    
    @classmethod
    def validate_structure(cls, df: pd.DataFrame) -> Tuple[bool, List[ValidationIssue]]:
        """Check if DataFrame has necessary columns."""
        issues = []
        
        # Critical columns
        for col in cls.CRITICAL_COLS:
            if col not in df.columns:
                issues.append(ValidationIssue(
                    level=ValidationLevel.CRITICAL,
                    message=f"Missing critical column: {col}",
                    column=col
                ))
        
        # Important columns
        for col in cls.IMPORTANT_COLS:
            if col not in df.columns:
                issues.append(ValidationIssue(
                    level=ValidationLevel.WARNING,
                    message=f"Missing important column: {col}",
                    column=col
                ))
        
        # Advanced columns
        present_adv = [c for c in cls.ADVANCED_COLS if c in df.columns]
        missing_adv = [c for c in cls.ADVANCED_COLS if c not in df.columns]
        
        if missing_adv:
            issues.append(ValidationIssue(
                level=ValidationLevel.INFO,
                message=f"Missing {len(missing_adv)}/{len(cls.ADVANCED_COLS)} advanced stats",
                count=len(missing_adv)
            ))
        
        has_critical = not any(i.level == ValidationLevel.CRITICAL for i in issues)
        return has_critical, issues
    
    @classmethod
    def validate_types(cls, df: pd.DataFrame) -> List[ValidationIssue]:
        """Check data types."""
        issues = []
        
        # Date column
        if 'date' in df.columns:
            if not pd.api.types.is_datetime64_any_dtype(df['date']):
                try:
                    pd.to_datetime(df['date'])
                except Exception:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.CRITICAL,
                        message="Column 'date' cannot be converted to datetime",
                        column='date'
                    ))
        
        # Score columns
        for col in ['home_score', 'away_score']:
            if col in df.columns and not pd.api.types.is_numeric_dtype(df[col]):
                issues.append(ValidationIssue(
                    level=ValidationLevel.CRITICAL,
                    message=f"Column '{col}' is not numeric",
                    column=col
                ))
        
        return issues
    
    @classmethod
    def validate_nulls(cls, df: pd.DataFrame) -> List[ValidationIssue]:
        """Check for null values in critical columns."""
        issues = []
        
        for col, spec in cls.CRITICAL_COLS.items():
            if col in df.columns and not spec.get('nullable', True):
                null_count = df[col].isnull().sum()
                if null_count > 0:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.CRITICAL,
                        message=f"Found {null_count} null values",
                        column=col,
                        count=null_count
                    ))
        
        return issues
    
    @classmethod
    def validate_logic(cls, df: pd.DataFrame) -> List[ValidationIssue]:
        """Check for logical impossibilities."""
        issues = []
        
        # Value ranges
        for col, (min_val, max_val) in cls.VALUE_RANGES.items():
            if col in df.columns:
                below = (df[col] < min_val).sum()
                above = (df[col] > max_val).sum()
                
                if below > 0:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        message=f"{below} values below minimum ({min_val})",
                        column=col,
                        count=below
                    ))
                
                if above > 0:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        message=f"{above} values above maximum ({max_val})",
                        column=col,
                        count=above
                    ))
        
        # Duplicate match_ids
        if 'match_id' in df.columns:
            dup_count = df['match_id'].duplicated().sum()
            if dup_count > 0:
                issues.append(ValidationIssue(
                    level=ValidationLevel.CRITICAL,
                    message=f"Found {dup_count} duplicate match_ids",
                    column='match_id',
                    count=dup_count
                ))
        
        # Zero-zero games
        if 'home_score' in df.columns and 'away_score' in df.columns:
            zero_games = ((df['home_score'] == 0) & (df['away_score'] == 0)).sum()
            if zero_games > 0:
                issues.append(ValidationIssue(
                    level=ValidationLevel.WARNING,
                    message=f"Found {zero_games} games with 0-0 score",
                    count=zero_games
                ))
        
        # Odds sanity
        if 'home_odds_close' in df.columns and 'away_odds_close' in df.columns:
            valid_odds = df[['home_odds_close', 'away_odds_close']].dropna()
            if len(valid_odds) > 0:
                implied = 1/valid_odds['home_odds_close'] + 1/valid_odds['away_odds_close']
                under_100 = (implied < 1.0).sum()
                if under_100 > 0:
                    issues.append(ValidationIssue(
                        level=ValidationLevel.WARNING,
                        message=f"{under_100} rows with <100% implied probability",
                        count=under_100
                    ))
        
        return issues
    
    @classmethod
    def validate_all(cls, df: pd.DataFrame) -> Tuple[bool, List[ValidationIssue]]:
        """Run all validations."""
        all_issues = []
        
        # Structure
        passed, struct_issues = cls.validate_structure(df)
        all_issues.extend(struct_issues)
        
        if not passed:
            return False, all_issues
        
        # Types
        all_issues.extend(cls.validate_types(df))
        
        # Nulls
        all_issues.extend(cls.validate_nulls(df))
        
        # Logic
        all_issues.extend(cls.validate_logic(df))
        
        has_critical = any(i.level == ValidationLevel.CRITICAL for i in all_issues)
        return not has_critical, all_issues
    
    @classmethod
    def report(cls, df: pd.DataFrame) -> bool:
        """Print validation report."""
        print("=" * 60)
        print("DATA VALIDATION REPORT")
        print("=" * 60)
        print(f"Rows: {len(df):,}")
        print(f"Columns: {len(df.columns)}")
        print()
        
        passed, issues = cls.validate_all(df)
        
        critical = [i for i in issues if i.level == ValidationLevel.CRITICAL]
        warnings = [i for i in issues if i.level == ValidationLevel.WARNING]
        info = [i for i in issues if i.level == ValidationLevel.INFO]
        
        if critical:
            print("❌ CRITICAL ISSUES:")
            for issue in critical:
                col_str = f" [{issue.column}]" if issue.column else ""
                count_str = f" (n={issue.count})" if issue.count else ""
                print(f"  - {issue.message}{col_str}{count_str}")
            print()
        
        if warnings:
            print("⚠️  WARNINGS:")
            for issue in warnings:
                col_str = f" [{issue.column}]" if issue.column else ""
                count_str = f" (n={issue.count})" if issue.count else ""
                print(f"  - {issue.message}{col_str}{count_str}")
            print()
        
        if info:
            print("ℹ️  INFO:")
            for issue in info:
                print(f"  - {issue.message}")
            print()
        
        if passed:
            print("✅ VALIDATION PASSED")
        else:
            print("❌ VALIDATION FAILED")
        
        return passed
