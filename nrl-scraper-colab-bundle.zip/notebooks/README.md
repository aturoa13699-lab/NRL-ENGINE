# Notebooks Guide (Colab)

These notebooks are Colab-friendly. Open them via the README badges or directly:

- `00_colab_bootstrap.ipynb`: sets up environment, installs deps, loads data from Parquet or read-only Postgres.
- `10_eda_baseline.ipynb`: quick EDA (margins, team trends).
- `20_model_baseline.ipynb`: simple ML baseline (logistic, LightGBM/XGBoost optional).

## Usage in Colab

1. Click the "Open in Colab" badge in the repo README (for the notebook you want).
2. Run the first cell to clone the repo and install dependencies.
3. Choose data source: Parquet exports or a read-only DB URL.
4. (Optional) Convert to HTML and push reports back to the repo.
