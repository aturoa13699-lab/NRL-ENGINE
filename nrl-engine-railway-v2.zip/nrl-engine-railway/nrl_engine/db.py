"""
Database Connection Module.

Handles PostgreSQL connection via SQLAlchemy.
Railway auto-injects DATABASE_URL.
"""
import pandas as pd
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SQLAlchemyError
from typing import Optional, List
from datetime import datetime

from nrl_engine.config import config


def get_engine():
    """Create database engine."""
    return create_engine(config.get_db_url())


def init_db():
    """Initialize database tables if they don't exist."""
    engine = get_engine()
    
    # Main match stats table
    create_match_stats = """
    CREATE TABLE IF NOT EXISTS match_stats (
        match_id TEXT PRIMARY KEY,
        date DATE NOT NULL,
        season INTEGER,
        round TEXT,
        venue TEXT,
        
        -- Teams
        home_team TEXT NOT NULL,
        away_team TEXT NOT NULL,
        
        -- Scores
        home_score INTEGER,
        away_score INTEGER,
        home_win INTEGER,
        
        -- Odds
        home_odds_close FLOAT,
        away_odds_close FLOAT,
        
        -- Possession & Completion
        home_possession_pct FLOAT,
        away_possession_pct FLOAT,
        home_completion_rate FLOAT,
        away_completion_rate FLOAT,
        
        -- Metres
        home_run_metres INTEGER,
        away_run_metres INTEGER,
        home_post_contact_metres INTEGER,
        away_post_contact_metres INTEGER,
        home_kick_metres INTEGER,
        away_kick_metres INTEGER,
        
        -- Attack
        home_line_breaks INTEGER,
        away_line_breaks INTEGER,
        home_tackle_breaks INTEGER,
        away_tackle_breaks INTEGER,
        home_offloads INTEGER,
        away_offloads INTEGER,
        
        -- Defense
        home_missed_tackles INTEGER,
        away_missed_tackles INTEGER,
        home_ineffective_tackles INTEGER,
        away_ineffective_tackles INTEGER,
        
        -- Discipline
        home_errors INTEGER,
        away_errors INTEGER,
        home_penalties INTEGER,
        away_penalties INTEGER,
        home_set_restarts INTEGER,
        away_set_restarts INTEGER,
        
        -- Kicking
        home_forced_dropouts INTEGER,
        away_forced_dropouts INTEGER,
        home_forty_20s INTEGER,
        away_forty_20s INTEGER,
        
        -- Referee
        referee TEXT,
        
        -- Metadata
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    
    # Features table (computed features for each match)
    create_features = """
    CREATE TABLE IF NOT EXISTS match_features (
        match_id TEXT PRIMARY KEY REFERENCES match_stats(match_id),
        
        -- ELO
        home_elo FLOAT,
        away_elo FLOAT,
        elo_diff FLOAT,
        elo_exp_home FLOAT,
        
        -- Pythagorean
        home_pythag FLOAT,
        away_pythag FLOAT,
        pythag_diff FLOAT,
        
        -- Form (rolling 5)
        home_5_win_rate FLOAT,
        away_5_win_rate FLOAT,
        home_5_margin FLOAT,
        away_5_margin FLOAT,
        
        -- Momentum
        home_momentum FLOAT,
        away_momentum FLOAT,
        home_streak INTEGER,
        away_streak INTEGER,
        
        -- Volatility
        home_volatility FLOAT,
        away_volatility FLOAT,
        match_volatility FLOAT,
        
        -- Context
        home_rest_days INTEGER,
        away_rest_days INTEGER,
        fatigue_advantage FLOAT,
        adjusted_hga_points FLOAT,
        
        -- H2H
        h2h_games INTEGER,
        h2h_home_win_rate FLOAT,
        
        -- Referee
        ref_games INTEGER,
        ref_home_bias FLOAT,
        ref_penalty_rate FLOAT,
        
        -- Market
        market_home_fair FLOAT,
        market_implied_margin FLOAT,
        
        -- Metadata
        feature_version TEXT,
        computed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    
    # Predictions table
    create_predictions = """
    CREATE TABLE IF NOT EXISTS predictions (
        id SERIAL PRIMARY KEY,
        match_id TEXT REFERENCES match_stats(match_id),
        
        -- Prediction
        pred_home_win_prob FLOAT,
        pred_home_win INTEGER,
        pred_margin FLOAT,
        
        -- Actual (filled after match)
        actual_home_win INTEGER,
        actual_margin INTEGER,
        
        -- Model info
        model_version TEXT,
        confidence FLOAT,
        
        -- Metadata
        predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    
    # ELO history table
    create_elo_history = """
    CREATE TABLE IF NOT EXISTS elo_history (
        id SERIAL PRIMARY KEY,
        date DATE,
        team TEXT,
        elo_rating FLOAT,
        match_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    
    # Referee stats table
    create_referee_stats = """
    CREATE TABLE IF NOT EXISTS referee_stats (
        referee TEXT PRIMARY KEY,
        total_games INTEGER,
        avg_penalties_per_game FLOAT,
        avg_total_points FLOAT,
        home_bias FLOAT,
        blowout_rate FLOAT,
        close_game_rate FLOAT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """
    
    with engine.connect() as conn:
        conn.execute(text(create_match_stats))
        conn.execute(text(create_features))
        conn.execute(text(create_predictions))
        conn.execute(text(create_elo_history))
        conn.execute(text(create_referee_stats))
        conn.commit()
    
    print("✅ Database initialized successfully.")


def table_exists(table_name: str) -> bool:
    """Check if a table exists."""
    engine = get_engine()
    inspector = inspect(engine)
    return table_name in inspector.get_table_names()


def save_matches(df: pd.DataFrame, table: str = "match_stats"):
    """
    Save match data to database with upsert logic.
    """
    if df.empty:
        print("⚠️ No data to save.")
        return 0
    
    engine = get_engine()
    
    # Add metadata columns
    df = df.copy()
    if 'created_at' not in df.columns:
        df['created_at'] = datetime.now()
    df['updated_at'] = datetime.now()
    
    # Derive home_win if not present
    if 'home_win' not in df.columns and 'home_score' in df.columns:
        df['home_win'] = (df['home_score'] > df['away_score']).astype(int)
    
    # Derive season if not present
    if 'season' not in df.columns and 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
        df['season'] = df['date'].dt.year
    
    # Get existing match_ids
    try:
        with engine.connect() as conn:
            result = conn.execute(text(f"SELECT match_id FROM {table}"))
            existing_ids = {row[0] for row in result}
    except SQLAlchemyError:
        existing_ids = set()
    
    # Split into new and updates
    if 'match_id' in df.columns:
        new_df = df[~df['match_id'].isin(existing_ids)]
        update_df = df[df['match_id'].isin(existing_ids)]
    else:
        new_df = df
        update_df = pd.DataFrame()
    
    # Insert new records
    saved = 0
    if not new_df.empty:
        try:
            new_df.to_sql(table, engine, if_exists='append', index=False)
            saved += len(new_df)
            print(f"✅ Inserted {len(new_df)} new records to {table}.")
        except SQLAlchemyError as e:
            print(f"⚠️ Error inserting: {e}")
    
    # Update existing (simple approach - delete and re-insert)
    if not update_df.empty:
        try:
            with engine.connect() as conn:
                for _, row in update_df.iterrows():
                    conn.execute(
                        text(f"DELETE FROM {table} WHERE match_id = :mid"),
                        {"mid": row['match_id']}
                    )
                conn.commit()
            update_df.to_sql(table, engine, if_exists='append', index=False)
            saved += len(update_df)
            print(f"✅ Updated {len(update_df)} existing records in {table}.")
        except SQLAlchemyError as e:
            print(f"⚠️ Error updating: {e}")
    
    return saved


def load_matches(
    seasons: Optional[List[int]] = None,
    limit: Optional[int] = None
) -> pd.DataFrame:
    """Load match data from database."""
    engine = get_engine()
    
    query = "SELECT * FROM match_stats WHERE 1=1"
    params = {}
    
    if seasons:
        query += " AND season IN :seasons"
        params['seasons'] = tuple(seasons)
    
    query += " ORDER BY date DESC"
    
    if limit:
        query += f" LIMIT {limit}"
    
    with engine.connect() as conn:
        df = pd.read_sql(text(query), conn, params=params)
    
    # Convert date column
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
    
    return df


def save_features(df: pd.DataFrame):
    """Save computed features to database."""
    return save_matches(df, table="match_features")


def save_predictions(df: pd.DataFrame):
    """Save predictions to database."""
    if df.empty:
        return 0
    
    engine = get_engine()
    
    df = df.copy()
    df['predicted_at'] = datetime.now()
    
    try:
        df.to_sql('predictions', engine, if_exists='append', index=False)
        print(f"✅ Saved {len(df)} predictions.")
        return len(df)
    except SQLAlchemyError as e:
        print(f"⚠️ Error saving predictions: {e}")
        return 0


def get_latest_elo_ratings() -> dict:
    """Get most recent ELO rating for each team."""
    engine = get_engine()
    
    query = """
    SELECT DISTINCT ON (team) team, elo_rating, date
    FROM elo_history
    ORDER BY team, date DESC
    """
    
    try:
        with engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
        return dict(zip(df['team'], df['elo_rating']))
    except SQLAlchemyError:
        return {}


def save_elo_history(team: str, elo: float, date, match_id: str):
    """Save ELO rating snapshot."""
    engine = get_engine()
    
    with engine.connect() as conn:
        conn.execute(
            text("""
                INSERT INTO elo_history (team, elo_rating, date, match_id)
                VALUES (:team, :elo, :date, :match_id)
            """),
            {"team": team, "elo": elo, "date": date, "match_id": match_id}
        )
        conn.commit()
