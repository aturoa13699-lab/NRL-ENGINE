"""
Tests for NRL Engine.
"""
import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

from nrl_engine.config import config
from nrl_engine.schema import DataValidator
from nrl_engine.engineer import FeatureEngineer
from nrl_engine.scraper import NRLScraper


class TestConfig:
    """Tests for configuration."""
    
    def test_config_defaults(self):
        """Test default configuration values."""
        assert config.feature_version == "v3.0.0"
        assert config.elo_initial == 1500.0
        assert config.pythagorean_exponent == 1.91
        assert len(config.rolling_windows) == 4
    
    def test_feature_exclude_contains_targets(self):
        """Ensure target columns are excluded from features."""
        assert 'home_win' in config.feature_exclude
        assert 'home_score' in config.feature_exclude
        assert 'away_score' in config.feature_exclude


class TestDataValidator:
    """Tests for data validation."""
    
    def test_validate_good_data(self):
        """Test validation passes for good data."""
        df = pd.DataFrame({
            'match_id': ['m1', 'm2'],
            'date': [datetime.now(), datetime.now()],
            'home_team': ['Team A', 'Team B'],
            'away_team': ['Team C', 'Team D'],
            'home_score': [24, 18],
            'away_score': [18, 12],
        })
        
        passed, issues = DataValidator.validate_all(df)
        
        assert passed
        critical = [i for i in issues if i.level.value == 'CRITICAL']
        assert len(critical) == 0
    
    def test_validate_missing_column(self):
        """Test validation fails for missing critical column."""
        df = pd.DataFrame({
            'match_id': ['m1'],
            'date': [datetime.now()],
            'home_team': ['Team A'],
            # Missing away_team, home_score, away_score
        })
        
        passed, issues = DataValidator.validate_structure(df)
        
        assert not passed
        assert any('away_team' in str(i.message) for i in issues)
    
    def test_validate_duplicates(self):
        """Test validation catches duplicate match_ids."""
        df = pd.DataFrame({
            'match_id': ['m1', 'm1'],  # Duplicate
            'date': [datetime.now(), datetime.now()],
            'home_team': ['Team A', 'Team B'],
            'away_team': ['Team C', 'Team D'],
            'home_score': [24, 18],
            'away_score': [18, 12],
        })
        
        issues = DataValidator.validate_logic(df)
        
        assert any('duplicate' in str(i.message).lower() for i in issues)


class TestScraper:
    """Tests for scraper."""
    
    def test_mock_data_generation(self):
        """Test mock data is generated correctly."""
        scraper = NRLScraper()
        df = scraper._generate_mock_data()
        
        assert not df.empty
        assert 'match_id' in df.columns
        assert 'home_team' in df.columns
        assert 'home_score' in df.columns
        assert len(df) >= 1
    
    def test_team_normalization(self):
        """Test team name normalization."""
        scraper = NRLScraper()
        
        assert scraper._normalize_team('broncos') == 'Brisbane Broncos'
        assert scraper._normalize_team('ROOSTERS') == 'Sydney Roosters'
        assert scraper._normalize_team('penrith') == 'Penrith Panthers'
    
    def test_run_scraper(self):
        """Test main scraper entry point."""
        from nrl_engine.scraper import run_scraper
        
        df = run_scraper()
        
        assert isinstance(df, pd.DataFrame)
        assert not df.empty


class TestFeatureEngineer:
    """Tests for feature engineering."""
    
    @pytest.fixture
    def sample_historical_data(self):
        """Generate sample historical data for testing."""
        teams = ['Brisbane Broncos', 'Sydney Roosters', 'Penrith Panthers', 'Melbourne Storm']
        matches = []
        
        base_date = datetime(2024, 3, 1)
        
        for i in range(50):
            home_idx = i % len(teams)
            away_idx = (i + 1) % len(teams)
            
            matches.append({
                'match_id': f'test_{i}',
                'date': base_date + timedelta(days=i * 7),
                'home_team': teams[home_idx],
                'away_team': teams[away_idx],
                'home_score': np.random.randint(10, 40),
                'away_score': np.random.randint(10, 40),
                'venue': 'Test Stadium',
                'referee': 'Test Referee',
                'home_odds_close': np.random.uniform(1.2, 3.0),
                'away_odds_close': np.random.uniform(1.2, 3.0),
            })
        
        return pd.DataFrame(matches)
    
    def test_engineer_initialization(self, sample_historical_data):
        """Test feature engineer initializes correctly."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        
        assert len(engineer.team_games) > 0
        assert len(engineer.elo_ratings) > 0
    
    def test_elo_computation(self, sample_historical_data):
        """Test ELO ratings are computed."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        
        # All teams should have ELO ratings
        for team in ['Brisbane Broncos', 'Sydney Roosters']:
            assert team in engineer.elo_ratings
            # ELO should be within reasonable range
            assert 1200 < engineer.elo_ratings[team] < 1800
    
    def test_compute_features_single_match(self, sample_historical_data):
        """Test computing features for a single match."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        
        match = pd.Series({
            'match_id': 'test_new',
            'date': datetime(2024, 12, 1),
            'home_team': 'Brisbane Broncos',
            'away_team': 'Sydney Roosters',
            'home_score': 24,
            'away_score': 18,
            'venue': 'Suncorp Stadium',
            'referee': 'Test Referee',
            'home_odds_close': 1.75,
            'away_odds_close': 2.10,
        })
        
        features = engineer.compute_features(match)
        
        # Check key features exist
        assert 'home_elo' in features
        assert 'away_elo' in features
        assert 'elo_diff' in features
        assert 'home_pythag' in features or features.get('home_pythag') is None
        assert 'market_home_fair' in features
    
    def test_process_dataframe(self, sample_historical_data):
        """Test processing entire dataframe."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        
        # Process last 5 matches
        new_data = sample_historical_data.tail(5).copy()
        processed = engineer.process(new_data)
        
        assert len(processed) == 5
        assert 'home_elo' in processed.columns
        assert 'elo_diff' in processed.columns
    
    def test_get_feature_columns(self, sample_historical_data):
        """Test feature column extraction."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        new_data = sample_historical_data.tail(5).copy()
        processed = engineer.process(new_data)
        
        feature_cols = engineer.get_feature_columns(processed)
        
        # Should have multiple feature columns
        assert len(feature_cols) > 10
        
        # Should not include excluded columns
        assert 'match_id' not in feature_cols
        assert 'home_team' not in feature_cols
        assert 'home_score' not in feature_cols
    
    def test_market_vectors(self, sample_historical_data):
        """Test market reverse-engineering."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        
        # Test with realistic odds
        result = engineer._compute_market(1.50, 2.60)
        
        assert result['market_home_fair'] is not None
        assert 0.55 < result['market_home_fair'] < 0.75  # Home favorite
        assert result['market_overround'] > 0  # Bookmaker margin
    
    def test_hga_vectors(self, sample_historical_data):
        """Test home ground advantage calculation."""
        engineer = FeatureEngineer(historical_data=sample_historical_data)
        
        result = engineer._compute_hga(
            'Brisbane Broncos',
            'Melbourne Storm',
            'suncorp_stadium'
        )
        
        assert 'adjusted_hga' in result
        assert result['adjusted_hga'] > 0  # Home advantage positive


class TestIntegration:
    """Integration tests for full pipeline."""
    
    def test_full_pipeline_mock_data(self):
        """Test complete pipeline with mock data."""
        # Scrape
        scraper = NRLScraper()
        raw_df = scraper._generate_mock_data()
        
        # Validate
        passed, _ = DataValidator.validate_all(raw_df)
        assert passed
        
        # Engineer
        engineer = FeatureEngineer(historical_data=raw_df)
        processed_df = engineer.process(raw_df)
        
        # Should have original + feature columns
        assert len(processed_df.columns) > len(raw_df.columns)
        
        # Get feature columns
        feature_cols = engineer.get_feature_columns(processed_df)
        assert len(feature_cols) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
