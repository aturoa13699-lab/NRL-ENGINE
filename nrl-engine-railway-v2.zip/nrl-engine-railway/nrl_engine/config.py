"""
NRL Engine Configuration.

Central control for all settings, paths, and hyperparameters.
Railway injects DATABASE_URL automatically.
"""
import os
from dataclasses import dataclass, field
from typing import List, Set, Dict, Optional
from dotenv import load_dotenv

# Load .env file if present (for local development)
load_dotenv()


@dataclass
class Config:
    """Global configuration parameters."""
    
    # =========================================================================
    # ENVIRONMENT
    # =========================================================================
    ENV: str = field(default_factory=lambda: os.getenv("ENV", "production"))
    DEBUG: bool = field(default_factory=lambda: os.getenv("DEBUG", "false").lower() == "true")
    
    # =========================================================================
    # DATABASE (Railway auto-injects DATABASE_URL)
    # =========================================================================
    DATABASE_URL: Optional[str] = field(default_factory=lambda: os.getenv("DATABASE_URL"))
    
    # =========================================================================
    # SCHEDULING (UTC time - Sydney is UTC+10/11)
    # =========================================================================
    SCRAPE_DAY: str = field(default_factory=lambda: os.getenv("SCRAPE_DAY", "tuesday"))
    SCRAPE_TIME: str = field(default_factory=lambda: os.getenv("SCRAPE_TIME", "22:00"))
    
    # Also run on Sunday for weekend results
    SCRAPE_DAY_2: str = field(default_factory=lambda: os.getenv("SCRAPE_DAY_2", "sunday"))
    SCRAPE_TIME_2: str = field(default_factory=lambda: os.getenv("SCRAPE_TIME_2", "10:00"))
    
    # =========================================================================
    # FEATURE ENGINEERING
    # =========================================================================
    feature_version: str = "v3.0.0"
    
    # Rolling windows (games)
    rolling_windows: List[int] = field(default_factory=lambda: [1, 3, 5, 10])
    min_games_for_rolling: int = 3
    
    # =========================================================================
    # ELO SETTINGS
    # =========================================================================
    elo_k: float = 20.0
    elo_home_advantage: float = 48.0
    elo_initial: float = 1500.0
    elo_season_regression: float = 0.33
    
    # =========================================================================
    # PYTHAGOREAN EXPECTATION
    # =========================================================================
    pythagorean_exponent: float = 1.91
    
    # =========================================================================
    # REFEREE SETTINGS
    # =========================================================================
    ref_min_games: int = 10
    ref_shrinkage_strength: int = 20
    
    # =========================================================================
    # MOMENTUM WEIGHTS
    # =========================================================================
    momentum_weights: Dict[str, float] = field(default_factory=lambda: {
        "win_rate": 0.30,
        "margin_trend": 0.25,
        "pcm_ratio": 0.25,
        "completion_rate": 0.20,
    })
    
    # =========================================================================
    # FEATURE EXCLUSIONS (for modeling)
    # =========================================================================
    feature_exclude: Set[str] = field(default_factory=lambda: {
        # Identifiers
        "match_id", "date", "timestamp", "round", "venue", "url",
        "home_team", "away_team", "referee", "season", "season_year",
        
        # Raw scores (potential leakage)
        "home_score", "away_score",
        
        # Targets
        "home_win", "win", "margin", "total_points",
        
        # Raw odds
        "home_odds_close", "away_odds_close",
        "home_odds_open", "away_odds_open",
        
        # Metadata
        "asof_ts", "feature_version", "created_at",
    })
    
    # =========================================================================
    # MODEL SETTINGS
    # =========================================================================
    random_seed: int = 42
    hgbc_max_iter: int = 100
    hgbc_max_depth: int = 5
    hgbc_learning_rate: float = 0.1
    
    # =========================================================================
    # VALIDATION
    # =========================================================================
    min_train_seasons: int = 2
    min_test_matches: int = 20
    odds_min_healthy_slope: float = 0.3
    min_model_correlation: float = 0.10
    max_acceptable_brier: float = 0.26
    
    # =========================================================================
    # SCRAPER SETTINGS
    # =========================================================================
    scraper_timeout: int = 30
    scraper_retries: int = 3
    scraper_delay: float = 2.0  # Seconds between requests
    
    def is_production(self) -> bool:
        return self.ENV == "production"
    
    def get_db_url(self) -> str:
        """Get database URL with postgres:// -> postgresql:// fix."""
        if not self.DATABASE_URL:
            raise ValueError("DATABASE_URL not set. Check Railway variables.")
        return self.DATABASE_URL.replace("postgres://", "postgresql://")


# Default singleton instance
config = Config()
