"""Tests for NRL Engine."""
